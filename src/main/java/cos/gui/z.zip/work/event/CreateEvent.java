package cos.gui.work.event;

import bin.exception.VariableException;
import cos.gui.etc.GuiToken;
import cos.gui.etc.EventItem;
import work.CreateWork;

public class CreateEvent extends CreateWork<EventItem> {
    public CreateEvent() {
        super(EventItem.class, GuiToken.ACTION_EVENT);
    }

    @Override
    protected Object createItem(Object[] params) {
        throw VariableException.DO_NOT_CREATE_KLASS.getThrow(GuiToken.ACTION_EVENT);
    }
}
