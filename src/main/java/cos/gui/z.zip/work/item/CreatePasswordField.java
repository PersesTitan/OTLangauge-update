package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.PassewordFieldItem;
import work.CreateWork;

public class CreatePasswordField extends CreateWork<PassewordFieldItem> {
    public CreatePasswordField() {
        super(PassewordFieldItem.class, GuiToken.PASSWORD_FILED);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new PassewordFieldItem();
    }
}
