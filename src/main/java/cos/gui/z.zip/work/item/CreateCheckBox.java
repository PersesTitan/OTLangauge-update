package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.CheckBoxItem;
import work.CreateWork;

public class CreateCheckBox extends CreateWork<CheckBoxItem> {
    public CreateCheckBox() {
        super(CheckBoxItem.class, GuiToken.CHECK_BOX);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new CheckBoxItem();
    }
}
