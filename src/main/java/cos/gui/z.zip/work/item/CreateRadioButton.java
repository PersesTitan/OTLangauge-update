package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.RadioButtonItem;
import work.CreateWork;

public class CreateRadioButton extends CreateWork<RadioButtonItem> {
    public CreateRadioButton() {
        super(RadioButtonItem.class, GuiToken.RADIO_BUTTON);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new RadioButtonItem();
    }
}
