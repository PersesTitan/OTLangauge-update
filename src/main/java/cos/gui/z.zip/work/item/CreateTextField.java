package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.TextFieldItem;
import work.CreateWork;

public class CreateTextField extends CreateWork<TextFieldItem> {
    public CreateTextField() {
        super(TextFieldItem.class, GuiToken.TEXT_FIELD);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new TextFieldItem();
    }
}
