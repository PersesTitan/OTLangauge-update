package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.TextAreaItem;
import work.CreateWork;

public class CreateTextArea extends CreateWork<TextAreaItem> {
    public CreateTextArea() {
        super(TextAreaItem.class, GuiToken.TEXT_AREA);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new TextAreaItem();
    }
}
