package cos.gui.work.item;

import cos.gui.etc.GuiToken;
import cos.gui.item.ButtonItem;
import work.CreateWork;

public class CreateButton extends CreateWork<ButtonItem> {
    public CreateButton() {
        super(ButtonItem.class, GuiToken.BUTTON);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new ButtonItem();
    }
}
