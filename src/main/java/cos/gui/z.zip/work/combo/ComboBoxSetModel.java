package cos.gui.work.combo;

import bin.variable.custom.CustomList;
import cos.gui.item.ComboBoxItem;
import work.StartWork;

public class ComboBoxSetModel<V> extends StartWork {
    public ComboBoxSetModel(String klassType, String params) {
        super(klassType, false, params);
    }

    @Override
    protected void startItem(Object klassValue, Object[] params) {
        ((ComboBoxItem<V>) klassValue).setModel((CustomList<V>) params[0]);
    }
}
