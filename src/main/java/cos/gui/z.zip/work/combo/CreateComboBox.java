package cos.gui.work.combo;

import cos.gui.item.ComboBoxItem;
import lombok.Getter;
import work.CreateWork;

@Getter
public class CreateComboBox<V> extends CreateWork<ComboBoxItem<V>> {
    private final String klassName;
    public CreateComboBox(String klassName) {
        super((Class<ComboBoxItem<V>>) new ComboBoxItem<V>().getClass(), klassName);
        this.klassName = klassName;
    }

    @Override
    protected Object createItem(Object[] params) {
        return new ComboBoxItem<V>();
    }

    @Override
    public boolean check(Object value) {
        return value instanceof CreateComboBox<?> comboBox
                && this.klassName.equals(comboBox.getKlassName());
    }
}
