package cos.gui.work.replace;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.ReplaceWork;

public class GetWidth extends ReplaceWork {
    public GetWidth(String klassType) {
        super(klassType, KlassToken.INT_VARIABLE, false);
    }

    @Override
    protected Object replaceItem(Object klassValue, Object[] params) {
        return ((EventTool) klassValue).getWidth();
    }
}
