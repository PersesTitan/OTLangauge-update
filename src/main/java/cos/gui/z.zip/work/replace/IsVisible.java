package cos.gui.work.replace;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.ReplaceWork;

public class IsVisible extends ReplaceWork {
    public IsVisible(String klassType) {
        super(klassType, KlassToken.BOOL_VARIABLE, false);
    }

    @Override
    protected Object replaceItem(Object klassValue, Object[] params) {
        return ((EventTool) klassValue).isVisible();
    }
}
