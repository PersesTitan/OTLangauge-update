package cos.gui.work.replace;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.ReplaceWork;

public class GetText extends ReplaceWork {
    public GetText(String klassType) {
        super(klassType, KlassToken.STRING_VARIABLE, false);
    }

    @Override
    protected Object replaceItem(Object klassValue, Object[] params) {
        return ((EventTool) klassValue).getText();
    }
}
