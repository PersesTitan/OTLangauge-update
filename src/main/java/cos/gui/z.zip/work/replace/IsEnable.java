package cos.gui.work.replace;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.ReplaceWork;

public class IsEnable extends ReplaceWork {
    public IsEnable(String klassType) {
        super(klassType, KlassToken.BOOL_VARIABLE, false);
    }

    @Override
    protected Object replaceItem(Object klassValue, Object[] params) {
        return ((EventTool) klassValue).isEnabled();
    }
}
