package cos.gui.work.start;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.StartWork;

public class SetText extends StartWork {
    public SetText(String klassName) {
        super(klassName, false, KlassToken.STRING_VARIABLE);
    }

    @Override
    protected void startItem(Object klassValue, Object[] params) {
        ((EventTool) klassValue).setText(params[0].toString());
    }
}
