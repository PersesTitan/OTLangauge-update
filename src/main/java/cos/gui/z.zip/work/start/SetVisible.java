package cos.gui.work.start;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.StartWork;

public class SetVisible extends StartWork {
    public SetVisible(String klassType) {
        super(klassType, false, KlassToken.BOOL_VARIABLE);
    }

    @Override
    protected void startItem(Object klassValue, Object[] params) {
        ((EventTool) klassValue).setVisible((boolean) params[0]);
    }
}
