package cos.gui.work.start;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.StartWork;

public class SetSize extends StartWork {
    public SetSize(String klassType) {
        super(klassType, false, KlassToken.INT_VARIABLE, KlassToken.INT_VARIABLE);
    }

    @Override
    protected void startItem(Object klassValue, Object[] params) {
        ((EventTool) klassValue).setSize((int) params[0], (int) params[1]);
    }
}
