package cos.gui.work.start;

import bin.token.KlassToken;
import cos.gui.etc.EventTool;
import work.StartWork;

public class SetEnabled extends StartWork {
    public SetEnabled(String klassType) {
        super(klassType, false, KlassToken.BOOL_VARIABLE);
    }

    @Override
    protected void startItem(Object klassValue, Object[] params) {
        ((EventTool) klassValue).setEnabled((boolean) params[0]);
    }
}
