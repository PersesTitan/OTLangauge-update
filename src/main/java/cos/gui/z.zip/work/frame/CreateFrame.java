package cos.gui.work.frame;

import cos.gui.etc.GuiToken;
import cos.gui.field.FrameItem;
import work.CreateWork;

public class CreateFrame extends CreateWork<FrameItem> {
    public CreateFrame() {
        super(FrameItem.class, GuiToken.FRAME);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new FrameItem();
    }
}
