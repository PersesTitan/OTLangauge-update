package cos.gui.work.frame;

import cos.gui.etc.GuiToken;
import cos.gui.field.PanelItem;
import work.CreateWork;

public class CreatePanel extends CreateWork<PanelItem> {
    public CreatePanel() {
        super(PanelItem.class, GuiToken.PANEL);
    }

    @Override
    protected Object createItem(Object[] params) {
        return new PanelItem();
    }
}
