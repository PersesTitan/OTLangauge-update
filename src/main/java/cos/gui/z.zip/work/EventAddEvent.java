package cos.gui.work;

import bin.apply.Read;
import bin.apply.mode.LoopMode;
import bin.repository.code.CodeMap;
import cos.gui.etc.EventTool;
import work.LoopWork;

public class EventAddEvent extends LoopWork {
    public EventAddEvent(String klassType) {
        super(LoopMode.PUT, klassType, false);
    }

    @Override
    protected int loopItem(int start, int end, LoopMode mode, CodeMap code, String repoKlass,
                           Object klassValue, Object[] params) {
        ((EventTool) klassValue).addEvent(code.get(end), () -> Read.read(code, start, end, null));
        return end;
    }
}
