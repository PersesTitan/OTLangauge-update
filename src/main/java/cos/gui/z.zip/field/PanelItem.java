package cos.gui.field;

import javax.swing.*;

public class PanelItem extends JPanel {

}
