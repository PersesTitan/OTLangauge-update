package cos.gui.field;

import javax.swing.*;
import java.awt.*;

public class FrameItem extends JFrame {
    @Override
    public Component add(Component comp) {
        return super.add(comp);
    }
}
