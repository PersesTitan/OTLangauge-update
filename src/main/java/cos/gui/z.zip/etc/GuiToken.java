package cos.gui.etc;

import bin.variable.Types;

public interface GuiToken {
    String GUI = "ㄱㅁㄱ-";

    String ACTION_EVENT = GUI + "ㅇㅃㅇ";

    String FRAME = GUI + "ㅍㄹㅍ";
    String PANEL = GUI + "ㅍㅇㅍ";

    String BUTTON           = GUI + "ㅂㅇㅂ";
    String CHECK_BOX        = GUI + "ㅊㅋㅊ";
    String RADIO_BUTTON     = GUI + "ㄹㅂㄹ";
    String TEXT_FIELD       = GUI + "ㅌㅍㅌ";
    String PASSWORD_FILED   = GUI + "ㅍㅍㅍ";
    String TEXT_AREA        = GUI + "ㅌㅇㅌ";

    String COMBO_BOX_INT       = GUI + "ㅋㅈㅋ";
    String COMBO_BOX_LONG      = GUI + "ㅋㅉㅋ";
    String COMBO_BOX_BOOL      = GUI + "ㅋㅂㅋ";
    String COMBO_BOX_STRING    = GUI + "ㅋㅁㅋ";
    String COMBO_BOX_CHARACTER = GUI + "ㅋㄱㅋ";
    String COMBO_BOX_FLOAT     = GUI + "ㅋㅅㅋ";
    String COMBO_BOX_DOUBLE    = GUI + "ㅋㅆㅋ";

    // METHOD
    String ADD_EVENT = "<ㅇㅃㅇ";
    String SET_MODEL = "<ㅁㄷㅁ";
    String ADD_KEY = "<ㅋㅂㅋ";
    String ADD_MOUSE = "<ㅁㅇㅁ";

    String SET_ENABLED = "<ㅇㄴㅇ";
    String GET_ENABLED = ">ㅇㄴㅇ";

    String SET_VISIBLE = "<ㅂㅈㅂ";
    String GET_VISIBLE = ">ㅂㅈㅂ";

    String SET_SIZE = "<ㅆㅈㅆ";
    String GET_WIDTH = ">ㄴㅂㄴ";  // 너비
    String GET_HEIGHT = ">ㄴㅍㄴ"; // 높이
    String GET_X = ">ㄱㄹㄱ";      // 가로
    String GET_Y = ">ㅅㄹㅅ";      // 세로

    String SET_TEXT = "<ㅌㅅㅌ";
    String GET_TEXT = ">ㅌㅅㅌ";
}
