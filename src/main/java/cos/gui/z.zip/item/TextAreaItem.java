package cos.gui.item;

import bin.apply.loop.LoopFunction;
import cos.gui.etc.EventTool;

import javax.swing.*;

public class TextAreaItem extends JTextArea implements EventTool {
    @Override
    public void addEvent(String endLine, LoopFunction function) {

    }
}
