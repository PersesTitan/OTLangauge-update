package cos.gui.item;

import bin.apply.loop.LoopFunction;
import bin.variable.custom.CustomList;
import cos.gui.etc.EventTool;

import javax.swing.*;
import java.util.Vector;

public class ComboBoxItem<V> extends JComboBox<V> implements EventTool {
    @Override
    public void addEvent(String endLine, LoopFunction function) {}

    @Override
    public void setText(String text) {}

    @Override
    public String getText() {
        return null;
    }

    public void setModel(CustomList<V> list) {
        Vector<V> vector = new Vector<>(list);
        this.setModel(new DefaultComboBoxModel<>(vector));
    }
}
